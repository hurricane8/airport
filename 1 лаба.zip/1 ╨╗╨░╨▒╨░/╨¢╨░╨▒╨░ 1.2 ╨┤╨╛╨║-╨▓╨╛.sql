select name, order_date, ship_date, datediff(dd, order_date, ship_date) as diff 
from customer 
inner join sales_order
on customer.customer_id=sales_order.customer_id