set transaction isolation level read uncommitted
begin transaction
declare @t1 date  
select @t1 = bith_date from Employee where employee_id=900
waitfor delay  '00:00:10'
update Employee set bith_date=dateadd(day,3,@t1)
where employee_id=900

select * from employee

commit