 sp_who
 kill 57