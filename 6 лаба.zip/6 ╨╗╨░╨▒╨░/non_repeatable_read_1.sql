set transaction isolation level read committed
--set transaction isolation level repeatable read
begin transaction
select * from employee where employee_id=902

select * from employee where job_id=302
 commit