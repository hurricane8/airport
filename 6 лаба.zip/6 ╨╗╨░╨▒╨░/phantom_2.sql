set transaction isolation level repeatable read
--set transaction isolation level serializable 
begin tran 
insert into employee values(915,'����','������','12-11-1980','9875642315','vanya@mail.ru', 302)
commit

















----SELECT @@TRANCOUNT