set transaction isolation level read uncommitted
--set transaction isolation level read committed
--set transaction isolation level repeatble read
--set transaction isolation level serializable 
begin tran
select bith_date from employee where employee_id = 903
update employee set bith_date=dateadd(day, 3, bith_date)
where employee_id = 902
update company set company.name = 'aaa' where company_id = 101
commit