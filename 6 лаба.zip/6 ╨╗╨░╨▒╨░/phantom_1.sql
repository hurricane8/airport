set transaction isolation level repeatable read
--set transaction isolation level serializable 
begin tran
select * from employee

select * from employee
commit 