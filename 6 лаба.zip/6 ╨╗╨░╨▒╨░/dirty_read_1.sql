set transaction isolation level read uncommitted
--set transaction isolation level read committed
begin transaction
select * from Company where company_id=100

select * from Company where Company_id=100
 commit
 select * from Company where Company_id=100

