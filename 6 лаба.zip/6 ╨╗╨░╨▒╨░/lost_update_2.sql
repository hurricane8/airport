set transaction isolation level read uncommitted
begin transaction


update Employee set bith_date=dateadd(day,3,bith_date)
where employee_id=900
--waitfor delay'00:00:10'



commit
select * from Employee