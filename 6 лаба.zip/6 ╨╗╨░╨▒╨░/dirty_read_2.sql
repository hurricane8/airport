set transaction isolation level read uncommitted
--set transaction isolation level read committed
begin transaction
update Company set Company.name='555'
rollback