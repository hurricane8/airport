set transaction isolation level read committed
--set transaction isolation level repeatable read
begin transaction
update employee 
set bith_date = dateadd(day, 3, bith_date) where employee_id=902

select * from employee where job_id=302
 commit