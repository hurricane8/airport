use db2

drop table Flight_crew
drop table Goods
drop table Flight_order
drop table Flight
drop table Orders
drop table Aircrafts
drop table Airports
drop table Cities
drop table Employee
drop table Model
drop table Countries
drop table Company
drop table [Time]
drop table Customers
drop table Goods_type
drop table Job



CREATE TABLE Countries
(
	country_id SMALLINT PRIMARY KEY IDENTITY(200,1) NOT NULL,
	name VARCHAR(30) NOT NULL
);

CREATE TABLE Company 
(
	company_id SMALLINT PRIMARY KEY IDENTITY(100, 1) NOT NULL,
	name VARCHAR(30) NOT NULL
);

CREATE TABLE [Time] 
(
	flight_id SMALLINT PRIMARY KEY NOT NULL,
	sup_dep_time DATETIME NOT NULL,
	real_dep_time DATETIME NOT NULL,
	sup_ar_time DATETIME NOT NULL,
	real_ar_time DATETIME NOT NULL,
	reasons VARCHAR(50)
);

CREATE TABLE Job 
(
	job_id SMALLINT PRIMARY KEY IDENTITY(300,1) NOT NULL,
	name VARCHAR(30) NOT NULL
);

CREATE TABLE Model 
(
	model_id SMALLINT PRIMARY KEY NOT NULL,
	model VARCHAR(30) NOT NULL,
	speed INT NOT NULL,
	max_distance INT NOT NULL,
	capacity_tons DECIMAL NOT NULL
);

CREATE TABLE Goods_type 
(
	good_type_id SMALLINT PRIMARY KEY NOT NULL,
	name VARCHAR(30) NOT NULL
);

CREATE TABLE Customers 
(
	customer_id SMALLINT PRIMARY KEY NOT NULL,
	customer_name VARCHAR(30) NOT NULL,
	phone VARCHAR(15) NOT NULL,
	email VARCHAR(30) NOT NULL
);

CREATE TABLE Aircrafts 
(
	aircraft_id SMALLINT PRIMARY KEY NOT NULL,
    model_id SMALLINT REFERENCES Model(model_id) on update cascade on delete cascade NOT NULL,
	inspection_date DATE NOT NULL
);

CREATE TABLE Cities 
(
	city_id SMALLINT PRIMARY KEY NOT NULL,
	name VARCHAR(30) NOT NULL,
	country_id SMALLINT REFERENCES Countries(country_id) on update cascade on delete cascade NOT NULL
);

CREATE TABLE Employee 
(
	employee_id SMALLINT PRIMARY KEY NOT NULL,
	first_name VARCHAR(30) NOT NULL,
	last_name VARCHAR(30) NOT NULL,
	bith_date DATE NOT NULL,
	phone VARCHAR(15) NOT NULL,
	email VARCHAR(30) NOT NULL,
	job_id SMALLINT REFERENCES Job(job_id) on update cascade on delete cascade NOT NULL 
);

CREATE TABLE Orders 
(
	order_id SMALLINT PRIMARY KEY NOT NULL,
	�ustomer_id SMALLINT REFERENCES Customers(customer_id) on update cascade on delete cascade NOT NULL,
	order_date DATE NOT NULL
);

CREATE TABLE Airports 
(
	airport_id SMALLINT PRIMARY KEY NOT NULL,
	iata_name VARCHAR(5) NOT NULL,
	name VARCHAR(30) NOT NULL,
	city_id SMALLINT REFERENCES Cities(city_id) on update cascade on delete cascade NOT NULL
);

CREATE TABLE Flight 
(
	flight_id SMALLINT PRIMARY KEY REFERENCES [Time](flight_id) on update cascade on delete cascade NOT NULL,
	company_id SMALLINT REFERENCES Company(company_id) on update cascade on delete cascade NOT NULL,
	aircraft_id SMALLINT REFERENCES Aircrafts(aircraft_id) on update cascade on delete cascade NOT NULL,
	airport_id SMALLINT REFERENCES Airports(airport_id) on update cascade on delete cascade NOT NULL,
	[type] BINARY NOT NULL,
    distance INT NOT NULL
);

CREATE TABLE Flight_crew 
(
	flight_id SMALLINT REFERENCES Flight(flight_id) on update cascade on delete cascade NOT NULL,
	employee_id SMALLINT REFERENCES Employee(employee_id) on update cascade on delete cascade NOT NULL,
	CONSTRAINT PK_flight_crew PRIMARY KEY 
	(
		flight_id,  
		employee_id  
	)
);

CREATE TABLE Flight_order 
(
    flight_id SMALLINT REFERENCES Flight(flight_id) on update cascade on delete cascade NOT NULL,
	order_id SMALLINT REFERENCES Orders(order_id) on update cascade on delete cascade NOT NULL,
	CONSTRAINT PK_flight_order PRIMARY KEY 
	(
		flight_id,  
		order_id  
	)
);

CREATE TABLE Goods (
	order_id SMALLINT REFERENCES Orders(order_id) on update cascade on delete cascade NOT NULL,
	good_type_id SMALLINT REFERENCES Goods_type(good_type_id) on update cascade on delete cascade NOT NULL,
	quantity_tons DECIMAL NOT NULL,
	CONSTRAINT PK_goods PRIMARY KEY 
	(
		order_id,  
		good_type_id  
	)
);

INSERT INTO Company VALUES	(	'�����-�����')	;
INSERT INTO Company VALUES	(	'����������������')	;
INSERT INTO Company VALUES	(	'�������������')	;
INSERT INTO Company VALUES	(	'������� ��������')	;
INSERT INTO Company VALUES	(	'�������� ��������')	;
INSERT INTO Company VALUES	(	'���� ��������')	;
INSERT INTO Company VALUES	(	'����� ��������')	;
INSERT INTO Company VALUES	(	'��������')	;
INSERT INTO Company VALUES	(	'��� ���')	;
INSERT INTO Countries VALUES	(	'������')	;
INSERT INTO Countries VALUES	(	'���')	;
INSERT INTO Countries VALUES	(	'��������')	;
INSERT INTO Countries VALUES	(	'����������')	;
INSERT INTO Countries VALUES	(	'������')	;
INSERT INTO Countries VALUES	(	'�������')	;
INSERT INTO Countries VALUES	(   '������')	;
INSERT INTO Countries VALUES	(	'�������')	;
INSERT INTO Countries VALUES	(	'�������')	;
INSERT INTO Countries VALUES	(	'��������')	;
INSERT INTO Countries VALUES	(	'���������')	;
INSERT INTO Job VALUES	('��������')	;
INSERT INTO Job VALUES	('������ �����')	;
INSERT INTO Job VALUES	('������� ')	;
INSERT INTO Job VALUES	('���������')	;
INSERT INTO [Time] VALUES	(400,	'15-07-2010 15:20:00'	,	'15-07-2010 15:20:00'	,	'15-07-2010 17:40:00'	,	'15-07-2010 17:40:00'	,	NULL	);
INSERT INTO [Time] VALUES	(401,	'15-08-2010 18:40:00'	,	'15-08-2010 20:40:00'	,	'16-08-2010 00:20:00'	,	'16-08-2010 02:20:00'	,	'������� �����'	);
INSERT INTO [Time] VALUES	(402,	'20-09-2010 21:15:00'	,	'20-09-2010 23:00:00'	,	'20-09-2010 23:00:00'	,	'21-09-2010 00:45:00'	,	'���� �� ���������'	);
INSERT INTO [Time] VALUES	(403,	'23-10-2010 08:45:00'	,	'23-10-2010 14:40:00'	,	'23-10-2010 21:05:00'   ,   '24-10-2010 03:00:00'	,	'������� �������'	);
INSERT INTO [Time] VALUES	(404,	'14-11-2010 09:50:00'	,	'14-11-2010 09:50:00'	,	'14-11-2010 15:30:00'	,	'14-11-2010 15:30:00'	,	NULL	);
INSERT INTO [Time] VALUES	(405,	'17-12-2010 06:15:00'	,	'18-12-2010 06:45:00'	,	'17-12-2010 06:35:00'	,	'17-12-2010 07:05:00'	,	'���� �� ���������'	);
INSERT INTO [Time] VALUES	(406,	'05-01-2011 08:20:00'	,	'05-01-2011 08:20:00'	,	'05-01-2011 14:10:00'	,	'05-01-2011 14:10:00'	,	NULL	);
INSERT INTO [Time] VALUES	(407,	'09-03-2011 06:30:00'	,	'09-03-2011 07:50:00'	,	'09-03-2011 14:10:00'	,	'09-03-2011 15:30:00'	,	'�����'	);
INSERT INTO [Time] VALUES	(408,	'08-05-2011 08:45:00'	,	'08-05-2011 12:25:00'	,	'08-05-2011 11:05:00'	,	'08-05-2011 14:45:00'	,	'���������� ��������'	);
INSERT INTO [Time] VALUES	(409,	'20-07-2011 10:00:00'	,	'20-07-2011 10:00:00'	,	'20-07-2011 11:30:00'	,   '20-07-2011 11:30:00'	,	NULL	);
INSERT INTO [Time] VALUES	(410,	'21-07-2011 12:00:00'	,	'21-07-2011 12:00:00'	,	'30-11-2011 22:15:00'	,	'01-12-2011 04:55:00'	,	'������� �����'	);
INSERT INTO [Time] VALUES	(411,	'26-10-2011 15:20:00'	,	'26-10-2011 15:20:00'   , '26-10-2011 22:00:00'	    ,	'26-10-2011 22:00:00',	NULL	);	
INSERT INTO [Time] VALUES	(412,	'30-11-2011 20:00:00'	,	'01-11-2011 02:40:00'   , '30-11-2011 22:15:00' 	,	'01-12-2011 04:55:00'	,	'������� �����'	);	
INSERT INTO [Time] VALUES	(413,	'29-12-2011 04:10:00'	,	'29-12-2011 04:10:00'	,	'29-12-2011 06:30:00'	,	'29-12-2011 06:30:00'	,	NULL	);
INSERT INTO [Time] VALUES	(414,	'05-01-2012 03:40:00'	,	'05-01-2012 07:40:00'	,	'05-01-2012 07:30:00'	,	'05-01-2012 11:30:00'	,	'������� �����'	);
INSERT INTO [Time] VALUES	(415,	'08-03-2012 04:50:00'	,	'08-03-2012 05:00:00'	,	'08-03-2012 08:20:00'	,	'08-03-2012 08:30:00'	,	'���� �� ���������'	);
INSERT INTO [Time] VALUES	(416,	'16-04-2012 06:50:00'	,	'16-04-2012 10:50:00'	,	'16-04-2012 10:05:00'	,	'16-04-2012 14:05:00'	,	'���� �� ���������'	);
INSERT INTO [Time] VALUES	(417,	'23-04-2012 05:00:00'	,	'23-04-2012 05:00:00'	,	'23-04-2012 10:45:00'	,	'23-04-2012 10:45:00'	,	NULL	);
INSERT INTO [Time] VALUES	(418,	'12-08-2015 04:55:00'	,	'12-08-2015 07:55:00'	,	'12-08-2015 09:25:00'	,	'12-08-2015 12:25:00'	,	'������� �������'	);
INSERT INTO [Time] VALUES	(419,	'13-09-2012 21:20:00'	,	'13-09-2012 21:20:00'	,	'14-09-2012 00:00:00'	,	'14-09-2012 00:00:00'	,	NULL	);
INSERT INTO [Time] VALUES	(420,	'05-10-2012 15:00:00'	,	'06-10-2012 01:00:00'	,	'05-10-2012 15:30:00'	,	'06-10-2012 01:30:00'	,	'������� �������'	);
INSERT INTO [Time] VALUES	(421,	'15-10-2012 15:20:00'	,	'15-10-2012 17:00:00'	,	'15-10-2012 22:00:00'	,	'15-10-2012 23:40:00'	,	'������� �������'	);
INSERT INTO [Time] VALUES	(422,	'13-01-2013 17:30:00'	,	'13-01-2013 17:30:00'	,	'13-01-2013 19:45:00'	,	'13-01-2013 19:45:00'	,	NULL	);
INSERT INTO [Time] VALUES	(423,	'14-03-2013 18:45:00'	,	'15-03-2013 01:30:00'	,	'14-03-2013 21:20:00'	,	'15-03-2013 04:10:00'	,	'������� �����'	);
INSERT INTO [Time] VALUES	(424,	'20-05-2013 20:15:00'	,	'20-05-2013 21:40:00'	,	'21-05-2013 00:05:00'	,	'21-05-2013 00:05:00'	,	'������� �����'	);
INSERT INTO [Time] VALUES	(425,	'25-08-2013 22:20:00'	,	'25-08-2013 22:20:00'	,	'26-08-2013 01:50:00'	,	'26-08-2013 01:50:00'	,	NULL	);
INSERT INTO [Time] VALUES	(426,	'15-10-2013 03:20:00'	,	'15-10-2013 05:40:00'	,	'15-10-2013 06:35:00'	,	'15-10-2013 08:55:00'	,	'�����'	);
INSERT INTO [Time] VALUES	(427,	'18-12-2013 05:40:00'	,	'18-12-2013 06:40:00'   ,	'18-12-2013 11:25:00'	,	'18-12-2013 12:25:00'	,	'�����'	);
INSERT INTO [Time] VALUES	(428,	'09-01-2014 09:00:00'	,	'09-01-2014 09:00:00'	,	'09-01-2014 13:30:00'	,	'09-01-2014 13:30:00'	,	NULL	);
INSERT INTO [Time] VALUES	(429,	'26-11-2014 10:00:00'	,	'26-11-2014 10:00:00'	,	'26-11-2014 12:40:00'	,	'26-11-2014 12:40:00'	,	NULL	);
INSERT INTO [Time] VALUES	(430,	'16-07-2015 15:00:00'	,	'16-07-2015 15:00:00'	,	'16-07-2015 17:25:00'	,	'16-07-2015 17:25:00'	,	NULL	);
INSERT INTO Goods_type VALUES	(500,	'��������'	);
INSERT INTO Goods_type VALUES	(501,	'������'	);
INSERT INTO Goods_type VALUES	(502,	'������'	);
INSERT INTO Goods_type VALUES	(503,	'��������'	);
INSERT INTO Goods_type VALUES	(504,	'���������'	);
INSERT INTO Goods_type VALUES	(505,	'������'	);
INSERT INTO Goods_type VALUES	(506,	'���������'	);
INSERT INTO Model VALUES	(600,	'��-124'	,	100	,	10000	,	200	);
INSERT INTO Model VALUES	(601,	'��-30'	,	150	,	15000	,	250	);
INSERT INTO Model VALUES	(602,	'����� 777'	,	200	,	15000	,	300	);
INSERT INTO Model VALUES	(603,	'������ � 320'	,	200	,	12000	,	400	);
INSERT INTO Model VALUES	(604,	'����� 707'	,	175	,	10000	,	300	);
INSERT INTO Model VALUES	(605,	'������ � 330'	,	100	,	16000	,	250	);
INSERT INTO Model VALUES	(606,	'��-134'	,	100	,	10000	,	150	);
INSERT INTO Aircrafts VALUES	(700,	600	,	'15-04-2010 00:00'	);	
INSERT INTO Aircrafts VALUES	(701,	601	,	'16-05-2010 00:00'	);	
INSERT INTO Aircrafts VALUES	(702,	603	,	'18-08-2010 00:00'	);	
INSERT INTO Aircrafts VALUES	(703,	606	,	'20-08-2010 00:00'	);	
INSERT INTO Aircrafts VALUES	(704,	604	,	'20-08-2010 00:00' 	);	
INSERT INTO Aircrafts VALUES	(705,	603	,	'05-01-2011 00:00'	);	
INSERT INTO Aircrafts VALUES	(706,	604	,	'06-02-2011 00:00'	);	
INSERT INTO Aircrafts VALUES	(707,	602	,	'06-08-2011 00:00'	);	
INSERT INTO Aircrafts VALUES	(708,	606	,	'08-09-2011 00:00'	);	
INSERT INTO Aircrafts VALUES	(709,	605	,	'10-12-2011 00:00'	);	
INSERT INTO Aircrafts VALUES	(710,	603	,	'12-11-2012 00:00'	);	
INSERT INTO Aircrafts VALUES	(711,	602	,	'25-02-2013 00:00'	);	
INSERT INTO Aircrafts VALUES	(712,	601	,	'25-05-2013 00:00'	);
INSERT INTO Aircrafts VALUES	(713,	603	,	'26-05-2013 00:00'	);
INSERT INTO Aircrafts VALUES	(714,	606	,	'27-05-2013 00:00'	);	
INSERT INTO Aircrafts VALUES	(715,	600	,	'30-12-2013 00:00'	);	
INSERT INTO Aircrafts VALUES	(716,	600	,	'24-01-2013 00:00'	);	
INSERT INTO Aircrafts VALUES	(717,	602	,	'25-02-2013 00:00'	);	
INSERT INTO Cities VALUES	(800,	'������'	,	200	);
INSERT INTO Cities VALUES	(801,	'��������'	,	209	);
INSERT INTO Cities VALUES	(802,	'�����'	,	207	);
INSERT INTO Cities VALUES	(803,	'������'	,	202	);
INSERT INTO Cities VALUES	(804,	'���'	,	204	);
INSERT INTO Cities VALUES	(805,	'�����-���������'	,	200	);
INSERT INTO Cities VALUES	(806,	'�����'	,	203	);
INSERT INTO Cities VALUES	(807,	'����'	,	208	);
INSERT INTO Cities VALUES	(808,	'���������'	,	205	);
INSERT INTO Cities VALUES	(809,	'������ �����'	,	210	);
INSERT INTO Cities VALUES	(810,	'���������'	,	201	);
INSERT INTO Cities VALUES	(811,	'������'	,	200	);
INSERT INTO Cities VALUES	(812,	'���-����'	,	201	);
INSERT INTO Employee VALUES	(900,	'������'	,	'������'	,	'15-12-1971',	'9778530343'		,	'andrey@mail.ru'	,	301	);
INSERT INTO Employee VALUES	(901,	'����'	,	'������'	,	'16-05-1960',	'9172367950'		,	'yura@mail.ru'	,	302	);
INSERT INTO Employee VALUES	(902,	'�����'	,	'������'	,	'23-08-1970',	'9033191353'		,	'ganochka@gmail.com'	,	302	);
INSERT INTO Employee VALUES	(903,	'������'	,	'�������'	,	'13-06-1975',	'9500750000'		,	'misha@yandex.ru'	,	300	);
INSERT INTO Employee VALUES	(904,	'�������'	,	'������'	,	'12-05-1980',	'9123456789'		,	'lesha@mail.ru'	,	302	);
INSERT INTO Employee VALUES	(905,	'����'	,	'�������'	,	'29-03-1985',	'9321654987'		,	'gagarin1961@gmail.com'	,	301	);
INSERT INTO Employee VALUES	(906,	'���������'	,	'��������'	,	'03-04-1991',	'9156489237'		,	'katyusha@mail.ru'	,	302	);
INSERT INTO Employee VALUES	(907,	'��������'	,	'���������'	,	'02-01-1986',	'9654987321'		,	'angel@gmail.com'	,	302	);
INSERT INTO Employee VALUES	(908,	'�������'	,	'����������'	,	'06-09-1982',	'9741852963'		,	'dima@yandex.ru'	,	300	);
INSERT INTO Employee VALUES	(909,	'�����'	,	'����������'	,	'22-05-1980',	'9369258147'	,	'masha@mail.ru'	,	302	);
INSERT INTO Employee VALUES	(910,	'���������'	,	'����������'	,	'23-04-1998',	'9654987312'		,	'sasha@mail.ru'	,	300	);
INSERT INTO Airports VALUES	(1000,	'VKO'	,	'�������'	,	800	);
INSERT INTO Airports VALUES	(1001,	'SHE'	,	'�����������'	,	800	);
INSERT INTO Airports VALUES	(1002,	'KAZ'	,	'������'	,	806	);
INSERT INTO Airports VALUES	(1003,	'NCH'	,	'��������'	,	807	);
INSERT INTO Airports VALUES	(1004,	'NYC'	,	'���-��������'	,	812	);
INSERT INTO Airports VALUES	(1005,	'WAS'	,	'����� ��������'	,	810	);
INSERT INTO Airports VALUES	(1006,	'BRA'	,	'������ ��������'	,	809	);
INSERT INTO Airports VALUES	(1007,	'SPN'	,	'�����'	,	808	);
INSERT INTO Airports VALUES	(1008,	'FRA'	,	'������ ��������'	,	802	);
INSERT INTO Airports VALUES	(1009,	'ITA'	,	'������'	,	804	);
INSERT INTO Customers VALUES	(1100,	'����� ���'	,	'9987987987'	,	'kargo@mail.ru'	);
INSERT INTO Customers VALUES	(1101,	'��� �����'	,	'9876546545'	,	'oookargo@mail.ru'	);
INSERT INTO Customers VALUES	(1102,	'��� ����'	,	'9852852852'	,	'oaogruz@yandex.ru'	);
INSERT INTO Customers VALUES	(1103,	'�� ���'	,	'9636363852'	,	'pak@mail.ru'	);
INSERT INTO Customers VALUES	(1104,	'������'	,	'9845845845'	,	'dhl@gmailcom'	);
INSERT INTO Customers VALUES	(1105,	'����� ���.'	,	'9658321547'	,	'kargoint@gmail.com'	);
INSERT INTO Customers VALUES	(1106,	'����������'	,	'9657324981'	,	'gruzov@yandex.ru'	);
INSERT INTO Customers VALUES	(1107,	'�������'	,	'9874563214'	,	'gruzila@mail.ru'	);
INSERT INTO Customers VALUES	(1108,	'��������'	,	'9556546542'	,	'gruzovik@mail.ru'	);
INSERT INTO Flight VALUES	(400,	100	,	700	,	1000	,	1	,	500	);
INSERT INTO Flight VALUES	(401,	101	,	701	,	1001	,	1	,	1000	);
INSERT INTO Flight VALUES	(402,	102	,	705	,	1009	,	0	,	1200	);
INSERT INTO Flight VALUES	(403,	104	,	717	,	1008	,	0	,	2000	);
INSERT INTO Flight VALUES	(404,	105	,	716	,	1002	,	0	,	5000	);
INSERT INTO Flight VALUES	(405,	106	,	715	,	1003	,	0	,	3000	);
INSERT INTO Flight VALUES	(406,	107	,	714	,	1004	,	1	,	1000	);
INSERT INTO Flight VALUES	(407,	104	,	712	,	1006	,	1	,	2000	);
INSERT INTO Flight VALUES	(408,	105	,	713	,	1005	,	1	,	3000	);
INSERT INTO Flight VALUES	(409,	106	,	710	,	1007	,	1	,	4000	);
INSERT INTO Flight VALUES	(410,	108	,	711	,	1006	,	0	,	6000	);
INSERT INTO Flight VALUES	(411,	105	,	712	,	1004	,	0	,	7000	);
INSERT INTO Flight VALUES	(412,	100	,	716	,	1005	,	0	,	5000	);
INSERT INTO Flight VALUES	(413,	107	,	710	,	1007	,	1	,	6000	);
INSERT INTO Flight VALUES	(414,	106	,	711	,	1002	,	1	,	4000	);
INSERT INTO Flight VALUES	(415,   108	,	704	,	1001	,	1	,	5500	);
INSERT INTO Flight VALUES	(416,	105	,	705	,	1000	,	1	,	4000	);
INSERT INTO Flight VALUES	(417,	104	,	706	,	1002	,	1	,	7000	);
INSERT INTO Flight VALUES	(418,	103	,	703	,	1003	,	1	,	6000	);
INSERT INTO Flight VALUES	(419,	103	,	702	,	1005	,	1	,	3000	);
INSERT INTO Flight VALUES	(420,	108	,	708	,	1006	,	0	,	8000	);
INSERT INTO Flight VALUES	(421,	107	,	709	,	1007	,	1	,	4000	);
INSERT INTO Flight VALUES	(422,	102	,	710	,	1008	,	0	,	2000	);
INSERT INTO Flight VALUES	(423,	101	,	715	,	1002	,	0	,	4000	);
INSERT INTO Flight VALUES	(424,	101	,	713	,	1003	,	1	,	5000	);
INSERT INTO Flight VALUES	(425,	103	,	715	,	1005	,	1	,	3000	);
INSERT INTO Flight VALUES	(426,	103	,	710	,	1004	,	1	,	2000	);
INSERT INTO Flight VALUES	(427,   106	,	711	,	1003	,	1	,	7000	);
INSERT INTO Flight VALUES	(428,	104	,	712	,	1002	,	0	,	6000	);
INSERT INTO Flight VALUES	(429,	105	,	710	,	1001	,	0	,	2200	);
INSERT INTO Flight VALUES	(430,	105	,	716	,	1004	,	0	,	1500	);
INSERT INTO Orders VALUES	(1200,	1100	,	'15-06-2010'	);
INSERT INTO Orders VALUES	(1201,	1102	,	'15-07-2010'	);
INSERT INTO Orders VALUES	(1202,	1103	,	'20-08-2010'	);
INSERT INTO Orders VALUES	(1203,	1108	,	'23-09-2010'	);
INSERT INTO Orders VALUES	(1204,	1105	,	'20-07-2011'	);
INSERT INTO Orders VALUES	(1205,	1104	,	'21-06-2011'	);
INSERT INTO Orders VALUES	(1206,	1102	,	'25-04-2013'	);
INSERT INTO Orders VALUES	(1207,	1101	,	'24-01-2014'	);
INSERT INTO Orders VALUES	(1208,	1104	,	'30-01-2015'	);
INSERT INTO Flight_crew VALUES	(400,	903 );
INSERT INTO Flight_crew VALUES	(400,	900	);
INSERT INTO Flight_crew VALUES	(400,	904	);
INSERT INTO Flight_crew VALUES	(400,	901	);
INSERT INTO Flight_crew VALUES	(400,	902	);
INSERT INTO Flight_crew VALUES	(400,	909	);
INSERT INTO Flight_crew VALUES	(401,	910	);
INSERT INTO Flight_crew VALUES	(401,	905	);
INSERT INTO Flight_crew VALUES	(401,	907	);
INSERT INTO Flight_crew VALUES	(401,	904	);
INSERT INTO Flight_crew VALUES	(401,	906	);
INSERT INTO Flight_crew VALUES	(401,	901	);
INSERT INTO Flight_crew VALUES	(402,	908	);
INSERT INTO Flight_crew VALUES	(402,	900	);
INSERT INTO Flight_crew VALUES	(402,	907	);
INSERT INTO Flight_crew VALUES	(402,	901	);
INSERT INTO Flight_crew VALUES	(402,	902	);
INSERT INTO Flight_crew VALUES	(402,	906	);
INSERT INTO Flight_crew VALUES	(403,	903	);
INSERT INTO Flight_crew VALUES	(403,	905	);
INSERT INTO Flight_crew VALUES	(403,	904	);
INSERT INTO Flight_crew VALUES	(403,	909	);
INSERT INTO Flight_crew VALUES	(403,	901	);
INSERT INTO Flight_crew VALUES	(403,	902	);
INSERT INTO Flight_crew VALUES	(404,	908	);
INSERT INTO Flight_crew VALUES	(404,	900	);
INSERT INTO Flight_crew VALUES	(404,	907	);
INSERT INTO Flight_crew VALUES	(404,	906	);
INSERT INTO Flight_crew VALUES	(404,	909	);
INSERT INTO Flight_crew VALUES	(404,	901	);
INSERT INTO Flight_crew VALUES	(405,	910	);
INSERT INTO Flight_crew VALUES	(405,	905	);
INSERT INTO Flight_crew VALUES	(405,	904	);
INSERT INTO Flight_crew VALUES	(405,	902	);
INSERT INTO Flight_crew VALUES	(405,	906	);
INSERT INTO Flight_crew VALUES	(405,	909	);
INSERT INTO Flight_crew VALUES	(406,	903	);
INSERT INTO Flight_crew VALUES	(406,	900	);
INSERT INTO Flight_crew VALUES	(406,	907	);
INSERT INTO Flight_crew VALUES	(406,	901	);
INSERT INTO Flight_crew VALUES	(406,	902	);
INSERT INTO Flight_crew VALUES	(406,	906	);
INSERT INTO Flight_crew VALUES	(407,	908	);
INSERT INTO Flight_crew VALUES	(407,	905	);
INSERT INTO Flight_crew VALUES	(407,	904	);
INSERT INTO Flight_crew VALUES	(407,	909	);
INSERT INTO Flight_crew VALUES	(407,	901	);
INSERT INTO Flight_crew VALUES	(407,	902	);
INSERT INTO Flight_crew VALUES	(408,	910	);
INSERT INTO Flight_crew VALUES	(408,	900	);
INSERT INTO Flight_crew VALUES	(408,	907	);
INSERT INTO Flight_crew VALUES	(408,	906	);
INSERT INTO Flight_crew VALUES	(408,	909	);
INSERT INTO Flight_crew VALUES	(408,	901	);
INSERT INTO Flight_crew VALUES	(409,	903	);
INSERT INTO Flight_crew VALUES	(409,	905	);
INSERT INTO Flight_crew VALUES	(409,	904	);
INSERT INTO Flight_crew VALUES	(409,	902	);
INSERT INTO Flight_crew VALUES	(409,	906	);
INSERT INTO Flight_crew VALUES	(409,	909	);
INSERT INTO Flight_crew VALUES	(410,	908	);
INSERT INTO Flight_crew VALUES	(410,	900	);
INSERT INTO Flight_crew VALUES	(410,	907	);
INSERT INTO Flight_crew VALUES	(410,	901	);
INSERT INTO Flight_crew VALUES	(410,	902	);
INSERT INTO Flight_crew VALUES	(410,	906	);
INSERT INTO Flight_crew VALUES	(411,	908	);
INSERT INTO Flight_crew VALUES	(411,	900	);
INSERT INTO Flight_crew VALUES	(411,	907	);
INSERT INTO Flight_crew VALUES	(411,	901	);
INSERT INTO Flight_crew VALUES	(411,	902	);
INSERT INTO Flight_crew VALUES	(411,	906	);
INSERT INTO Flight_crew VALUES	(412,	908	);
INSERT INTO Flight_crew VALUES	(412,	900	);
INSERT INTO Flight_crew VALUES	(412,	907	);
INSERT INTO Flight_crew VALUES	(412,	901	);
INSERT INTO Flight_crew VALUES	(412,	902	);
INSERT INTO Flight_crew VALUES	(412,	909	);
INSERT INTO Flight_crew VALUES	(413,	908	);
INSERT INTO Flight_crew VALUES	(413,	905	);
INSERT INTO Flight_crew VALUES	(413,	904	);
INSERT INTO Flight_crew VALUES	(413,	901	);
INSERT INTO Flight_crew VALUES	(413,	902	);
INSERT INTO Flight_crew VALUES	(413,	906	);
INSERT INTO Flight_crew VALUES	(414,	910	);
INSERT INTO Flight_crew VALUES	(414,	900	);
INSERT INTO Flight_crew VALUES	(414,	907	);
INSERT INTO Flight_crew VALUES	(414,	909	);
INSERT INTO Flight_crew VALUES	(414,	901	);
INSERT INTO Flight_crew VALUES	(414,	902	);
INSERT INTO Flight_crew VALUES	(415,	903	);
INSERT INTO Flight_crew VALUES	(415,	905	);
INSERT INTO Flight_crew VALUES	(415,	904	);
INSERT INTO Flight_crew VALUES	(415,	906	);
INSERT INTO Flight_crew VALUES	(415,	909	);
INSERT INTO Flight_crew VALUES	(415,	901	);
INSERT INTO Flight_crew VALUES	(416,	908	);
INSERT INTO Flight_crew VALUES	(416,	900	);
INSERT INTO Flight_crew VALUES	(416,	907	);
INSERT INTO Flight_crew VALUES	(416,	906	);
INSERT INTO Flight_crew VALUES	(416,	909	);
INSERT INTO Flight_crew VALUES	(416,	901	);
INSERT INTO Flight_crew VALUES	(417,	910	);
INSERT INTO Flight_crew VALUES	(417,	905	);
INSERT INTO Flight_crew VALUES	(417,	904	);
INSERT INTO Flight_crew VALUES	(417,	902	);
INSERT INTO Flight_crew VALUES	(417,	906	);
INSERT INTO Flight_crew VALUES	(417,	909	);
INSERT INTO Flight_crew VALUES	(418,	903	);
INSERT INTO Flight_crew VALUES	(418,	905	);
INSERT INTO Flight_crew VALUES	(418,	907	);
INSERT INTO Flight_crew VALUES	(418,	901	);
INSERT INTO Flight_crew VALUES	(418,	902	);
INSERT INTO Flight_crew VALUES	(418,	906	);
INSERT INTO Flight_crew VALUES	(419,	908	);
INSERT INTO Flight_crew VALUES	(419,	900	);
INSERT INTO Flight_crew VALUES	(419,	904	);
INSERT INTO Flight_crew VALUES	(419,	909	);
INSERT INTO Flight_crew VALUES	(419,	901	);
INSERT INTO Flight_crew VALUES	(419,	902	);
INSERT INTO Flight_crew VALUES	(420,	910	);
INSERT INTO Flight_crew VALUES	(420,	905	);
INSERT INTO Flight_crew VALUES	(420,	907	);
INSERT INTO Flight_crew VALUES	(420,	906	);
INSERT INTO Flight_crew VALUES	(420,	909	);
INSERT INTO Flight_crew VALUES	(420,	901	);
INSERT INTO Flight_crew VALUES	(421,	908	);
INSERT INTO Flight_crew VALUES	(421,	900	);
INSERT INTO Flight_crew VALUES	(421,	904	);
INSERT INTO Flight_crew VALUES	(421,	902	);
INSERT INTO Flight_crew VALUES	(421,	906	);
INSERT INTO Flight_crew VALUES	(421,	909	);
INSERT INTO Flight_crew VALUES	(422,	908	);
INSERT INTO Flight_crew VALUES	(422,	905	);
INSERT INTO Flight_crew VALUES	(422,	907	);
INSERT INTO Flight_crew VALUES	(422,	901	);
INSERT INTO Flight_crew VALUES	(422,	902	);
INSERT INTO Flight_crew VALUES	(422,	906	);
INSERT INTO Flight_crew VALUES	(423,	910	);
INSERT INTO Flight_crew VALUES	(423,	900	);
INSERT INTO Flight_crew VALUES	(423,	904	);
INSERT INTO Flight_crew VALUES	(423,	909	);
INSERT INTO Flight_crew VALUES	(423,	901	);
INSERT INTO Flight_crew VALUES	(423,	902	);
INSERT INTO Flight_crew VALUES	(424,	903	);
INSERT INTO Flight_crew VALUES	(424,	905	);
INSERT INTO Flight_crew VALUES	(424,	907	);
INSERT INTO Flight_crew VALUES	(424,	906	);
INSERT INTO Flight_crew VALUES	(424,	909	);
INSERT INTO Flight_crew VALUES	(424,	901	);
INSERT INTO Flight_crew VALUES	(425,	908	);
INSERT INTO Flight_crew VALUES	(425,	900	);
INSERT INTO Flight_crew VALUES	(425,	904	);
INSERT INTO Flight_crew VALUES	(425,	902	);
INSERT INTO Flight_crew VALUES	(425,	906	);
INSERT INTO Flight_crew VALUES	(425,	909	);
INSERT INTO Flight_crew VALUES	(426,	910	);
INSERT INTO Flight_crew VALUES	(426,	905	);
INSERT INTO Flight_crew VALUES	(426,	907	);
INSERT INTO Flight_crew VALUES	(426,	901	);
INSERT INTO Flight_crew VALUES	(426,	902	);
INSERT INTO Flight_crew VALUES	(426,	906	);
INSERT INTO Flight_crew VALUES	(427,	903	);
INSERT INTO Flight_crew VALUES	(427,	900	);
INSERT INTO Flight_crew VALUES	(427,	904	);
INSERT INTO Flight_crew VALUES	(427,	909	);
INSERT INTO Flight_crew VALUES	(427,	901	);
INSERT INTO Flight_crew VALUES	(427,	902	);
INSERT INTO Flight_crew VALUES	(428,	908	);
INSERT INTO Flight_crew VALUES	(428,	905	);
INSERT INTO Flight_crew VALUES	(428,	907	);
INSERT INTO Flight_crew VALUES	(428,	906	);
INSERT INTO Flight_crew VALUES	(428,	909	);
INSERT INTO Flight_crew VALUES	(428,	901	);
INSERT INTO Flight_crew VALUES	(429,	910	);
INSERT INTO Flight_crew VALUES	(429,	900	);
INSERT INTO Flight_crew VALUES	(429,	904	);
INSERT INTO Flight_crew VALUES	(429,	902	);
INSERT INTO Flight_crew VALUES	(429,	906	);
INSERT INTO Flight_crew VALUES	(429,	909	);
INSERT INTO Flight_crew VALUES	(430,	903	);
INSERT INTO Flight_crew VALUES	(430,	905	);
INSERT INTO Flight_crew VALUES	(430,	907	);
INSERT INTO Flight_crew VALUES	(430,	901	);
INSERT INTO Flight_crew VALUES	(430,	902	);
INSERT INTO Flight_crew VALUES	(430,	906	);
INSERT INTO Flight_order VALUES	(400,	1200	);
INSERT INTO Flight_order VALUES	(400,	1201	);
INSERT INTO Flight_order VALUES	(401,	1200	);
INSERT INTO Flight_order VALUES	(401,	1201	);
INSERT INTO Flight_order VALUES	(402,	1202	);
INSERT INTO Flight_order VALUES	(403,	1200	);
INSERT INTO Flight_order VALUES	(403,	1201	);
INSERT INTO Flight_order VALUES	(404,	1200	);
INSERT INTO Flight_order VALUES	(405,	1201	);
INSERT INTO Flight_order VALUES	(405,	1200	);
INSERT INTO Flight_order VALUES	(406,	1201	);
INSERT INTO Flight_order VALUES	(407,	1202	);
INSERT INTO Flight_order VALUES	(408,	1202	);
INSERT INTO Flight_order VALUES	(408,	1203	);
INSERT INTO Flight_order VALUES	(409,	1203	);
INSERT INTO Flight_order VALUES	(410,	1202	);
INSERT INTO Flight_order VALUES	(411,	1201	);
INSERT INTO Flight_order VALUES	(411,	1202	);
INSERT INTO Flight_order VALUES	(412,	1201	);
INSERT INTO Flight_order VALUES	(413,	1202	);
INSERT INTO Flight_order VALUES	(414,	1200	);
INSERT INTO Flight_order VALUES	(414,	1202	);
INSERT INTO Flight_order VALUES	(415,	1204	);
INSERT INTO Flight_order VALUES	(416,	1203	);
INSERT INTO Flight_order VALUES	(417,	1204	);
INSERT INTO Flight_order VALUES	(417,	1205	);
INSERT INTO Flight_order VALUES	(418,	1202	);
INSERT INTO Flight_order VALUES	(419,	1205	);
INSERT INTO Flight_order VALUES	(420,	1205	);
INSERT INTO Flight_order VALUES	(420,	1204	);
INSERT INTO Flight_order VALUES	(421,	1205	);
INSERT INTO Flight_order VALUES	(422,	1206	);
INSERT INTO Flight_order VALUES	(423,	1206	);
INSERT INTO Flight_order VALUES	(424,	1205	);
INSERT INTO Flight_order VALUES	(424,	1206	);
INSERT INTO Flight_order VALUES	(425,	1206	);
INSERT INTO Flight_order VALUES	(426,	1205	);
INSERT INTO Flight_order VALUES	(426,	1206	);
INSERT INTO Flight_order VALUES	(427,	1205	);
INSERT INTO Flight_order VALUES	(428,	1207	);
INSERT INTO Flight_order VALUES	(429,	1207	);
INSERT INTO Flight_order VALUES	(429,	1206	);
INSERT INTO Flight_order VALUES	(430,	1208	);
INSERT INTO Goods VALUES	(1200,	500	,	70	);
INSERT INTO Goods VALUES	(1200,	501	,	80	);
INSERT INTO Goods VALUES	(1201,	502	,	90	);
INSERT INTO Goods VALUES	(1201,	503	,	100	);
INSERT INTO Goods VALUES	(1201,	504	,	110	);
INSERT INTO Goods VALUES	(1201,	505	,	100	);
INSERT INTO Goods VALUES	(1202,	506	,	20	);
INSERT INTO Goods VALUES	(1202,	500	,	50	);
INSERT INTO Goods VALUES	(1202,	501	,	75	);
INSERT INTO Goods VALUES	(1203,	502	,	40	);
INSERT INTO Goods VALUES	(1203,	503	,	60	);
INSERT INTO Goods VALUES	(1204,	504	,	50	);
INSERT INTO Goods VALUES	(1205,	505	,	70	);
INSERT INTO Goods VALUES	(1205,	506	,	80	);
INSERT INTO Goods VALUES	(1205,	500	,	15	);
INSERT INTO Goods VALUES	(1206,	501	,	20	);
INSERT INTO Goods VALUES	(1206,	502	,	30	);
INSERT INTO Goods VALUES	(1207,	503	,	90	);
INSERT INTO Goods VALUES	(1207,	504	,	95	);
INSERT INTO Goods VALUES	(1208,	505	,	95	);






















