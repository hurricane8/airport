SET STATISTICS IO ON
SET STATISTICS TIME ON

SELECT *  INTO Customers_no_index FROM Customers
SELECT *  INTO Orders_no_index FROM Orders

CREATE CLUSTERED INDEX Cus_cl_index ON Customers (CustomerID)
CREATE CLUSTERED INDEX Ord_cl_index ON Orders (CustomerID) 

CREATE NONCLUSTERED INDEX Ord_noncl_index ON Orders(OrderDate, ShipCity) INCLUDE (CustomerID);
CREATE NONCLUSTERED INDEX Cus_noncl_index ON Customers(Country) INCLUDE (CompanyName, CustomerID);

-----������ ��� �������

SELECT CompanyName, OrderDate, ShipCity
FROM Customers_no_index a
	INNER JOIN Orders_no_index b
	ON a.customerid = b.customerid
WHERE a.country BETWEEN 'USA' AND 'USA'
	AND b.OrderDate BETWEEN '19970101' AND '19971231'

-----������ � ��������

SELECT CompanyName, OrderDate, ShipCity
FROM Customers a
	INNER JOIN Orders b
	ON a.customerid = b.customerid
WHERE a.country BETWEEN 'USA' AND 'USA'
	AND b.OrderDate BETWEEN '19970105' AND '19971225'




DROP INDEX Cus_cl_index ON Customers
DROP INDEX Ord_cl_index ON Orders
DROP INDEX Ord_noncl_index ON Orders
DROP INDEX Cus_noncl_index ON Customers