SET STATISTICS IO ON
SET STATISTICS TIME ON

SELECT *  INTO Customers_no_index FROM Customers
SELECT *  INTO Orders_no_index FROM Orders
SELECT *  INTO OrderDetails_no_index FROM OrderDetails
SELECT *  INTO Products_no_index FROM Products

CREATE CLUSTERED INDEX Cl_Customers ON Customers(CustomerID)
CREATE CLUSTERED INDEX Cl_Orders ON Orders(CustomerID,OrderID)
CREATE CLUSTERED INDEX Cl_Products ON Products (ProductID)
CREATE CLUSTERED INDEX Cl_OrderDetails ON OrderDetails (OrderID,ProductID)

CREATE NONCLUSTERED INDEX Non_Customers ON Customers(City)
CREATE NONCLUSTERED INDEX Non_Orders ON Orders(EmployeeID)
CREATE NONCLUSTERED INDEX Non_Products ON Products (UnitsInStock)
CREATE NONCLUSTERED INDEX Non_OrderDetails ON OrderDetails (Discount)

--��� �������

SELECT Customers_no_index.CustomerID, EmployeeID, City, Products_no_index.ProductID, Products_no_index.UnitsInStock, 
	   OrderDetails_no_index.Discount
FROM Customers_no_index, Orders_no_index, OrderDetails_no_index, Products_no_index
WHERE Customers_no_index.CustomerID = Orders_no_index.CustomerID AND
	  Orders_no_index.OrderID = OrderDetails_no_index.OrderID AND
	  OrderDetails_no_index.ProductID = Products_no_index.ProductID AND
	  EmployeeID = 1 AND
	  City = 'London' AND
	  OrderDetails_no_index.Discount = 0 AND
	  Products_no_index.UnitsInStock < 20

--� ��������

SELECT Customers.CustomerID, EmployeeID, City, Products.ProductID, Products.UnitsInStock, OrderDetails.Discount
FROM Customers, Orders, OrderDetails, Products
WHERE Customers.CustomerID = Orders.CustomerID AND
	  Orders.OrderID = OrderDetails.OrderID AND
	  OrderDetails.ProductID = Products.ProductID AND
	  EmployeeID = 1 AND
	  City = 'London' AND
	  OrderDetails.Discount = 0 AND
	  Products.UnitsInStock < 20

DROP INDEX Clast_Customers ON Customers
DROP INDEX Clast_Orders ON Orders
DROP INDEX Clast_Products ON Products
DROP INDEX Clast_OrderDetails ON OrderDetails

DROP INDEX Non_Customers ON Customers
DROP INDEX Non_Orders ON Orders
DROP INDEX Non_Products ON Products
DROP INDEX Non_OrderDetails ON OrderDetails



/*EXEC sp_helpindex customers
EXEC sp_helpindex orders
EXEC sp_helpindex Products
EXEC sp_helpindex OrderDetails*/

