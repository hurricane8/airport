
use dbb
if object_id('max_dist') is not null 
drop trigger max_dist
go
create trigger max_dist on flight after insert, update
as
if exists
	(select * from inserted 
				   inner join Flight on inserted.flight_id = FLight.flight_id
				   inner join Aircrafts on FLight.flight_id = Aircrafts.aircraft_id
				   inner join Model on Model.model_id = Aircrafts.model_id
				   where Model.max_distance < Flight.distance)
begin
delete from Flight 
	   where Flight.flight_id in 
	   (select Flight.flight_id from Flight 
	   inner join Aircrafts on Aircrafts.aircraft_id = Flight.aircraft_id 
	   inner join Model on Model.model_id = Aircrafts.model_id
	   inner join inserted on inserted.flight_id = Flight.flight_id
	   where Model.max_distance < Flight.distance)
end
go

begin tran 
insert into [Time] values (433, '15-07-2010 15:20:00','15-07-2010 15:20:00','15-07-2010 17:40:00','15-07-2010 17:40:00',NULL)	
insert into Flight values (433, 102, 700, 1000, 1, 3000)

insert into [Time] values (436, '15-07-2010 15:20:00','15-07-2010 15:20:00','15-07-2010 17:40:00','15-07-2010 17:40:00',NULL)
insert into Flight values (436, 101, 701, 1001, 0, 1000)


select flight_id, distance, max_distance from FLight 
			  inner join Aircrafts on Aircrafts.aircraft_id = Flight.aircraft_id
			  inner join Model on Model.model_id = Aircrafts.model_id 

rollback
update Flight 
set aircraft_id = 702 where Flight.flight_id = 433

select * from sys.triggers