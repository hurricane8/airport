if object_id('table_create') is not null
drop table table_create
CREATE TABLE table_create
(
    EventDate    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    TableName   NVARCHAR(255),
    Login_user_name    NVARCHAR(255)
);
USE dbbb;
GO
CREATE TRIGGER creator
    ON DATABASE
	FOR CREATE_TABLE
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE
        @EventData XML = EVENTDATA();
 
    DECLARE 
        @ip VARCHAR(32) =
        (
            SELECT client_net_address
                FROM sys.dm_exec_connections
                WHERE session_id = @@SPID
        );
 
    INSERT table_create
    (
        TableName,
        Login_user_name
    )
    SELECT
        @EventData.value('(/EVENT_INSTANCE/ObjectName)[1]',  'NVARCHAR(255)'),
        SUSER_SNAME();
END
GO


select * from table_create

create table Test1
(
	a int,
	b int
)
