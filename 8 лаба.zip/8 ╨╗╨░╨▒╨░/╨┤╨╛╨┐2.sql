select a.name as name, x.name as table_name, y.name as table_par, col.name  from sysobjects as a, sysusers, syscolumns as col, sysreferences as a1
										 inner join
										 sysobjects as x on a1.fkeyid= x.id
										 inner join
										 sysobjects as y on a1.rkeyid=y.id
where a.uid = sysusers.uid and
sysusers.name = user_name() and
col.colid = a1.rkeyindid and
col.id = x.id and
x.xtype = 'U' and
a.xtype = 'F' and
a.id = a1.constid

