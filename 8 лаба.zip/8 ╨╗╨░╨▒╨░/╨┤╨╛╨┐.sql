select * from sysusers 
where sysusers.sid in (select [Transaction ID] from fn_dblog(NULL, NULL)
WHERE
    [Transaction Name] = 'DROPOBJ')

	SELECT * FROM fn_dblog(NULL, NULL) WHERE [Transaction Name] = 'DROPOBJ'
