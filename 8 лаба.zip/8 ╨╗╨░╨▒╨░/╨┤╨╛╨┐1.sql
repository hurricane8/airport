BACKUP LOG ��2 
       TO DISK= 'C:SQLBackupNorth.bak' 
       WITH NO_TRUNCATE



SELECT Description FROM fn_dblog(NULL, NULL) WHERE [Transaction Name] = 'DROPOBJ'

declare @TranID varchar(256)
SELECT
    @TranID= [Transaction ID]
FROM
    fn_dblog(NULL, NULL)
WHERE
    [Transaction Name] = 'DROPOBJ'

exec as user = 'user_1'
if object_id('v6') is not null
drop view v6

select * from sysusers 
where sysusers.sid in (select [Transaction ID] from fn_dblog(NULL, NULL)
WHERE
    [Transaction Name] = 'DROPOBJ')
	
	
	
	 
select @TranID
SELECT
    *
FROM 
    sysusers
WHERE
    sid = @TranID

select * from sysobjects 
where